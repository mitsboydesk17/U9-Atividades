function adicionarTarefa() {
    let input = document.getElementById("tarefa");
    let valor = input.value.trim();

    if (valor === "") {
        alert("Digite uma tarefa!");
        return;
    }

    let li = document.createElement("li");
    li.innerText = valor;

    let botaoRemover = document.createElement("button");
    botaoRemover.innerText = "Remover";
    botaoRemover.className = "btn-remove";
    botaoRemover.onclick = function() {
        li.parentNode.removeChild(li);
    };

    li.appendChild(botaoRemover);
    document.getElementById("lista").appendChild(li);


    input.value = "";

    }

function alternarModo() {
    document.body.classList.toggle('dark');
}
